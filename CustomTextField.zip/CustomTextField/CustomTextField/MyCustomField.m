//
//  MyCustomField.m
//  CustomTextField
//
//  Created by 乐玑_李玉琴 on 2017/9/5.
//  Copyright © 2017年 lyq. All rights reserved.
//

#import "MyCustomField.h"

@interface MyCustomField()

@end

@implementation MyCustomField
{
    CALayer *lineLayer;
    UILabel *label;
}
- (id)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.userInteractionEnabled  = YES;
        self.clipsToBounds = YES;            
    }
    return self;

}

- (void)setLeftViewText:(NSString *)leftStr{
    self.leftViewMode = UITextFieldViewModeAlways;
    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 108, 30)];
    
    UILabel *letfView = [[UILabel alloc]initWithFrame:CGRectMake(25, 0, CGRectGetWidth(bgView.frame) - 25, 30)];
    letfView.font = [UIFont systemFontOfSize:16];
    letfView.textColor = [UIColor grayColor];
    letfView.text = leftStr;
    [bgView addSubview:letfView];
    self.leftView = bgView;
}

- (void)setLeftViewImage:(NSString *)imageStr{
    self.leftViewMode = UITextFieldViewModeAlways;
    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 60, 30)];
    UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 0, 30, 30)];
    [bgView addSubview:imgView];
    imgView.image = [UIImage imageNamed:imageStr];
    
    self.leftView = bgView;
}

- (void)setRightViewImage:(NSString *)imageStr{
    self.rightViewMode = UITextFieldViewModeAlways;
    UIView *bgView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 60, 30)];
    bgView.userInteractionEnabled = YES;
    UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(20, 15/2, 18, 15)];
    imgView.userInteractionEnabled = YES;
    [bgView addSubview:imgView];
    imgView.image = [UIImage imageNamed:imageStr];
    UITapGestureRecognizer *imageTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(imageTapAction:)];
    [imgView addGestureRecognizer:imageTap];
    self.rightView = bgView;
}

- (void)imageTapAction:(UITapGestureRecognizer *)sender{
    UIImageView *imageView = (UIImageView *)sender.view;
    self.rightBlcok(imageView);
    
}
- (void)setInnerShadow{
    CAShapeLayer* shadowLayer = [CAShapeLayer layer];
    [shadowLayer setFrame:self.bounds];
    // Standard shadow stuff
    [shadowLayer setShadowColor:[[UIColor grayColor] CGColor]];
    [shadowLayer setShadowOffset:CGSizeMake(0.1f, 0.1f)];
    [shadowLayer setShadowOpacity:1.0f];
    [shadowLayer setShadowRadius:5];
    
    // Causes the inner region in this example to NOT be filled.
    [shadowLayer setFillRule:kCAFillRuleEvenOdd];
    
    // Create the larger rectangle path.
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, CGRectInset(self.bounds, -35, -35));
    
    // Add the inner path so it's subtracted from the outer path.
    // someInnerPath could be a simple bounds rect, or maybe
    // a rounded one for some extra fanciness.
    CGPathRef someInnerPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:5.0f].CGPath;
    CGPathAddPath(path, NULL, someInnerPath);
    CGPathCloseSubpath(path);
    
    [shadowLayer setPath:path];
    CGPathRelease(path);
    
    [[self layer] addSublayer:shadowLayer];
    
    CAShapeLayer* maskLayer = [CAShapeLayer layer];
    [maskLayer setPath:someInnerPath];
    [shadowLayer setMask:maskLayer];
}


#pragma mark set/get
- (void)setPlaceHolder:(NSString *)placeHolder{
    _placeHolder = placeHolder;
    self.placeholder = _placeHolder;
}
- (void)setFontSize:(CGFloat)fontSize{
    _fontSize = fontSize;
    self.font = [UIFont systemFontOfSize:_fontSize];
}
- (void)setTextColors:(id)textColors{
    _textColors = textColors;
    self.textColor = _textColors;
}
- (void)setTextAlignments:(NSTextAlignment)textAlignments{
    _textAlignments = textAlignments;
    self.textAlignment = _textAlignments;
}

@end
