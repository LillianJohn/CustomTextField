//
//  AppDelegate.h
//  CustomTextField
//
//  Created by 乐玑_李玉琴 on 2017/9/5.
//  Copyright © 2017年 lyq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

