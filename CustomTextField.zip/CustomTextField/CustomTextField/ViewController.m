//
//  ViewController.m
//  CustomTextField
//
//  Created by 乐玑_李玉琴 on 2017/9/5.
//  Copyright © 2017年 lyq. All rights reserved.
//

#define WIDTH  [UIScreen mainScreen].bounds.size.width
#define HEIGHT [UIScreen mainScreen].bounds.size.height

#import "ViewController.h"
#import "MyCustomField.h"

@interface ViewController ()

@property (nonatomic, strong) MyCustomField * leftTextField;
@property (nonatomic, strong) MyCustomField * rightImageField;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.rightImageField = [[MyCustomField alloc]initWithFrame:CGRectZero];
    [self.view addSubview:self.rightImageField];
    self.rightImageField.frame = CGRectMake(20, 80, WIDTH-40, 40);
    [self.rightImageField setRightViewImage:@"rightImage"];
    self.rightImageField.layer.borderWidth = .5;
    self.rightImageField.layer.cornerRadius = 10;
    self.rightImageField.layer.borderColor = [UIColor grayColor].CGColor;
    self.rightImageField.placeHolder=@"选择文本信息";
    self.rightImageField.fontSize = 14;
    self.rightImageField.textAlignments = NSTextAlignmentCenter;
    [self.rightImageField setRightBlcok:^(UIImageView *imageView){
        NSLog(@"点击了image");
    }];
    
    self.leftTextField = [[MyCustomField alloc]initWithFrame:CGRectZero];
    [self.view addSubview:self.leftTextField];
    self.leftTextField.frame = CGRectMake(20, 150, WIDTH-40, 40);
    [self.leftTextField setLeftViewImage:@"leftImage"];
    self.leftTextField.layer.borderWidth = .5;
    self.leftTextField.layer.cornerRadius = 10;
    self.leftTextField.layer.borderColor = [UIColor grayColor].CGColor;
    self.leftTextField.placeHolder=@"选择文本信息";
    self.leftTextField.fontSize = 14;
    self.leftTextField.textAlignments = NSTextAlignmentLeft;
    
    self.leftTextField = [[MyCustomField alloc]initWithFrame:CGRectZero];
    [self.view addSubview:self.leftTextField];
    self.leftTextField.frame = CGRectMake(20, 220, WIDTH-40, 40);
    [self.leftTextField setLeftViewText:@"左信息："];
    self.leftTextField.layer.borderWidth = .5;
    self.leftTextField.layer.cornerRadius = 10;
    self.leftTextField.layer.borderColor = [UIColor grayColor].CGColor;
    self.leftTextField.placeHolder=@"选择文本信息";
    self.leftTextField.fontSize = 14;
    self.leftTextField.textAlignments = NSTextAlignmentLeft;
    //设置阴影
    [self.leftTextField setInnerShadow];
    
    

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
