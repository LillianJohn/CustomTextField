//
//  MyCustomField.h
//  CustomTextField
//
//  Created by 乐玑_李玉琴 on 2017/9/5.
//  Copyright © 2017年 lyq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCustomField : UITextField

/**占位字符*/
@property (nonatomic, copy) NSString *placeHolder;
/**字体大小*/
@property (nonatomic, assign) CGFloat fontSize;
/**字体颜色*/
@property (nonatomic, copy) id textColors;
/**对齐方式*/
@property (nonatomic, assign) NSTextAlignment textAlignments;


/**
 设置左视图文字

 @param leftStr 文字
 */
- (void)setLeftViewText:(NSString *)leftStr;
/**
 设置左视图image

 @param imageStr 图片名称
 */
- (void)setLeftViewImage:(NSString *)imageStr;
/**
 设置右视图image

 @param imageStr 图片名称
 */
- (void)setRightViewImage:(NSString *)imageStr;
/**设置内阴影*/
- (void)setInnerShadow;

@property (nonatomic,copy)void (^rightBlcok)(UIImageView *);

@end
