//
//  main.m
//  CustomTextField
//
//  Created by 乐玑_李玉琴 on 2017/9/5.
//  Copyright © 2017年 lyq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
